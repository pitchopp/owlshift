module.exports = "owlshift-fixture-dep 1.0.0";
